import type { DomainEvent } from "../../shared/contracts";

// Projection-only input: callers must retain the original frames for cursor
// deduplication, checkpoints, follow policy, telemetry and other projections.
export function coalesceChatEvents(
  events: readonly DomainEvent[],
): DomainEvent[] {
  const projected: DomainEvent[] = [];
  let head: DomainEvent | undefined;
  let fragments: string[] = [];
  const flush = () => {
    if (!head) return;
    projected.push(
      fragments.length === 1
        ? head
        : { ...head, data: { ...head.data, delta: fragments.join("") } },
    );
    head = undefined;
    fragments = [];
  };
  for (const event of events) {
    const ordinal = event?.data?.messageIndex;
    const compatible =
      event?.type === "message.delta" &&
      typeof event.threadId === "string" &&
      !!event.threadId &&
      typeof event.turnId === "string" &&
      !!event.turnId &&
      typeof event.itemId === "string" &&
      !!event.itemId &&
      !!event.data &&
      typeof event.data === "object" &&
      !Array.isArray(event.data) &&
      typeof event.data.delta === "string" &&
      (ordinal === undefined ||
        (Number.isSafeInteger(ordinal) && ordinal >= 0));
    if (!compatible) {
      flush();
      projected.push(event);
      continue;
    }
    if (
      head &&
      (head.threadId !== event.threadId ||
        head.turnId !== event.turnId ||
        head.itemId !== event.itemId ||
        head.data.messageIndex !== ordinal)
    )
      flush();
    head ??= event;
    fragments.push(event.data.delta);
  }
  flush();
  return projected;
}
